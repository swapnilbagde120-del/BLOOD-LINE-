# BloodLine — World-Class Blood Network

**Tagline:** Every Drop Connects a Life.

Android app prototype built with Kotlin + Jetpack Compose + Material 3.

## Included
- Emergency blood request flow
- Blood-group matching
- Nearby donor/blood-bank discovery UI
- Live tracking / ETA screen (demo state, ready for real GPS + routing backend)
- Blood-stock dashboard
- AI assistant UI for search and guidance
- Secure-profile UI and verification indicators
- Donation history
- Notification-ready architecture
- Premium light/dark medical UI

## Important
This repository intentionally does **not** fake live medical data. Live stock, donor location, ETA, OTP and AI answers need real services/backend credentials before production.

Recommended production stack:
- Firebase Auth / phone OTP
- Firestore or PostgreSQL
- FCM push notifications
- Google Maps/Mapbox routing
- Server-side geospatial matching
- Role-based access and audit logs
- Encrypted sensitive data and minimal retention

## Build
Open in Android Studio and run:
`./gradlew assembleDebug`

For real-time features, connect the repository interfaces/data layer to your backend and map provider.
