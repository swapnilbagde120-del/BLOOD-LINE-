package com.bloodline.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BloodRed = Color(0xFFC62828)
private val DeepRed = Color(0xFF8E1111)
private val SoftRed = Color(0xFFFFEBEE)
private val Ink = Color(0xFF17202A)
private val Groups = listOf("A+","A-","B+","B-","O+","O-","AB+","AB-")

data class Donor(val name: String, val group: String, val distance: String, val verified: Boolean)
data class Stock(val group: String, val units: Int, val status: String)

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BloodLineTheme { BloodLineApp(locationPermission) } }
    }
}

@Composable
fun BloodLineTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BloodRed,
            onPrimary = Color.White,
            secondary = DeepRed,
            background = Color(0xFFF8F9FA),
            surface = Color.White,
            onSurface = Ink
        ),
        typography = Typography(
            headlineLarge = LocalTextStyle.current.copy(fontSize = 31.sp, fontWeight = FontWeight.Black),
            titleLarge = LocalTextStyle.current.copy(fontSize = 21.sp, fontWeight = FontWeight.Bold)
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BloodLineApp(permissionLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>) {
    var page by remember { mutableStateOf("home") }
    var selectedGroup by remember { mutableStateOf("O+") }
    var aiOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("BloodLine", fontWeight = FontWeight.Black)
                        Text("Every Drop Connects a Life.", fontSize = 11.sp, color = Color.Gray)
                    }
                },
                actions = {
                    TextButton(onClick = { aiOpen = true }) { Text("AI", fontWeight = FontWeight.Black) }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    "home" to "Home", "find" to "Find", "request" to "Emergency",
                    "track" to "Track", "profile" to "Profile"
                ).forEach { (id, label) ->
                    NavigationBarItem(
                        selected = page == id,
                        onClick = { page = id },
                        icon = { Text(if (id=="home") "⌂" else if(id=="find") "⌖" else if(id=="request") "!" else if(id=="track") "◉" else "●") },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (page) {
                "home" -> HomeScreen(
                    group = selectedGroup,
                    onEmergency = { page = "request" },
                    onTrack = { page = "track" },
                    onFind = { page = "find" },
                    onLocation = {
                        permissionLauncher.launch(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ))
                    }
                )
                "find" -> FindScreen(selectedGroup) { selectedGroup = it }
                "request" -> EmergencyScreen(selectedGroup) { selectedGroup = it; page = "track" }
                "track" -> TrackScreen()
                else -> ProfileScreen()
            }

            if (aiOpen) {
                ModalBottomSheet(onDismissRequest = { aiOpen = false }) {
                    AIAssistant()
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun HomeScreen(group: String, onEmergency: () -> Unit, onTrack: () -> Unit, onFind: () -> Unit, onLocation: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = DeepRed)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Need blood now?", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("Find compatible donors and nearby blood centres faster.", color = Color.White.copy(.85f))
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = onEmergency,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepRed)
                    ) { Text("🚨  CREATE EMERGENCY REQUEST", fontWeight = FontWeight.Black) }
                }
            }
        }
        item { Text("Your live dashboard", style = MaterialTheme.typography.titleLarge) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Metric("12", "Nearby donors"); Metric("4", "Blood centres"); Metric("8 min", "Fastest ETA")
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Live location", fontWeight = FontWeight.Bold)
                    Text("Location is used only to improve nearby matching.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = onLocation, modifier = Modifier.fillMaxWidth()) { Text("📍 Use my current location") }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Current blood need", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text("Selected group: $group", fontSize = 24.sp, fontWeight = FontWeight.Black, color = BloodRed)
                    Text("Matching uses blood group + distance + donor availability.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onFind) { Text("Find matches") }
                        OutlinedButton(onClick = onTrack) { Text("Track request") }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = SoftRed)) {
                Column(Modifier.padding(18.dp)) {
                    Text("🛡 Trust & safety", fontWeight = FontWeight.Bold)
                    Text("Verified profiles • request audit trail • role-based access • no fake live data", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable fun Metric(value: String, label: String) {
    Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black, color = BloodRed)
            Text(label, fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun FindScreen(group: String, setGroup: (String) -> Unit) {
    val donors = listOf(
        Donor("Rahul P.", "O+", "1.2 km", true),
        Donor("Sneha M.", "O+", "2.8 km", true),
        Donor("Amit K.", "A+", "3.4 km", true),
        Donor("Neha J.", "AB+", "4.1 km", true)
    )
    val stock = listOf(
        Stock("O+", 18, "Good"), Stock("A+", 11, "Good"), Stock("B+", 6, "Low"),
        Stock("AB+", 3, "Low"), Stock("O-", 2, "Critical")
    )
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Find blood", style = MaterialTheme.typography.headlineLarge) }
        item { Text("Blood group", color = Color.Gray) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                Groups.take(4).forEach { g -> FilterChip(selected = group==g, onClick={setGroup(g)}, label={Text(g)}) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                Groups.drop(4).forEach { g -> FilterChip(selected = group==g, onClick={setGroup(g)}, label={Text(g)}) }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Nearby blood centres", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("LIVE MAP READY", color = BloodRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Connect Google Maps/Mapbox + your backend for actual GPS, routes and ETA.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFECEFF1))) {
                        Text("⌖   MAP / LIVE ROUTE", Modifier.align(Alignment.Center), color = Color.DarkGray, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Text("Compatible donors", style = MaterialTheme.typography.titleLarge) }
        items(donors.filter { it.group == group || group == "O+" && it.group == "A+" }) { d ->
            DonorCard(d)
        }
        item { Text("Blood stock", style = MaterialTheme.typography.titleLarge) }
        items(stock) { s -> StockCard(s) }
    }
}

@Composable fun DonorCard(d: Donor) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(SoftRed), contentAlignment=Alignment.Center) {
                Text("♥", color=BloodRed, fontSize=22.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, fontWeight=FontWeight.Bold)
                Text("${d.group}  •  ${d.distance}", color=Color.Gray, fontSize=13.sp)
            }
            if (d.verified) Text("✓", color=BloodRed, fontWeight=FontWeight.Black, fontSize=22.sp)
        }
    }
}

@Composable fun StockCard(s: Stock) {
    Card(shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(s.group, fontSize=20.sp, fontWeight=FontWeight.Black, color=BloodRed, modifier=Modifier.width(58.dp))
            Column(Modifier.weight(1f)) {
                Text("${s.units} units available", fontWeight=FontWeight.Bold)
                Text("Official centre data required for production", color=Color.Gray, fontSize=11.sp)
            }
            AssistChip(onClick={}, label={Text(s.status)})
        }
    }
}

@Composable
fun EmergencyScreen(group: String, setGroup: (String) -> Unit) {
    var units by remember { mutableStateOf("2") }
    var hospital by remember { mutableStateOf("") }
    var urgent by remember { mutableStateOf(true) }
    var created by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("Emergency request", style=MaterialTheme.typography.headlineLarge) }
        item {
            Card(shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=SoftRed)) {
                Column(Modifier.padding(17.dp)) {
                    Text("🚨 Priority matching", fontWeight=FontWeight.Black, color=DeepRed)
                    Text("Only create a request for a genuine medical need. Hospital/centre verification should be enabled in production.", fontSize=12.sp)
                }
            }
        }
        item { Text("Blood group") }
        item { GroupSelector(group, setGroup) }
        item { OutlinedTextField(value=units,onValueChange={units=it},label={Text("Units needed")},modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value=hospital,onValueChange={hospital=it},label={Text("Hospital / centre")},modifier=Modifier.fillMaxWidth()) }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Checkbox(checked=urgent,onCheckedChange={urgent=it})
                Text("Mark as urgent", fontWeight=FontWeight.Bold)
            }
        }
        item {
            Button(
                onClick={created=true},
                modifier=Modifier.fillMaxWidth().height(54.dp),
                shape=RoundedCornerShape(16.dp)
            ) { Text(if(created) "REQUEST CREATED ✓" else "SEND EMERGENCY REQUEST", fontWeight=FontWeight.Black) }
        }
        if (created) item {
            Card(shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(17.dp)) {
                    Text("Request ID: BL-DEMO-2048", fontWeight=FontWeight.Black)
                    Text("$group • $units units • ${if(urgent) "URGENT" else "NORMAL"}", color=Color.Gray)
                    Text("Next: connect verified donors/centres and enable real-time tracking.", fontSize=12.sp)
                }
            }
        }
    }
}

@Composable fun GroupSelector(group:String,setGroup:(String)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) { Groups.take(4).forEach { g -> FilterChip(group==g,{setGroup(g)},{Text(g)}) } }
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) { Groups.drop(4).forEach { g -> FilterChip(group==g,{setGroup(g)},{Text(g)}) } }
    }
}

@Composable
fun TrackScreen() {
    var live by remember { mutableStateOf(true) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("Live tracking", style=MaterialTheme.typography.headlineLarge) }
        item {
            Card(shape=RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("BL-DEMO-2048", fontWeight=FontWeight.Black, modifier=Modifier.weight(1f))
                        AssistChip(onClick={live=!live}, label={Text(if(live) "LIVE" else "PAUSED")})
                    }
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFFECEFF1))) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("📍", fontSize=34.sp)
                            Text("LIVE MAP + ROUTE", fontWeight=FontWeight.Black)
                            Text("Real GPS/routing required", color=Color.Gray, fontSize=12.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Estimated arrival", color=Color.Gray)
                    Text("08–12 min", fontSize=32.sp, fontWeight=FontWeight.Black, color=BloodRed)
                    Text("ETA becomes real only after the courier/donor device shares location.", color=Color.Gray, fontSize=12.sp)
                }
            }
        }
        item { Step("✓", "Request verified", "Hospital/request details received") }
        item { Step("✓", "Donor / centre matched", "Compatibility and availability checked") }
        item { Step("→", "On the way", "Live GPS will update ETA") }
        item { Step("○", "Delivered", "Final handover recorded in audit trail") }
    }
}

@Composable fun Step(icon:String,title:String,sub:String) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(if(icon=="✓") SoftRed else Color(0xFFECEFF1)), contentAlignment=Alignment.Center) {
            Text(icon, color=if(icon=="✓") BloodRed else Color.Gray, fontWeight=FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column { Text(title, fontWeight=FontWeight.Bold); Text(sub, color=Color.Gray, fontSize=12.sp) }
    }
}

@Composable
fun ProfileScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("Profile & security", style=MaterialTheme.typography.headlineLarge) }
        item {
            Card(shape=RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp).clip(CircleShape).background(SoftRed),contentAlignment=Alignment.Center) {
                            Text("♥", color=BloodRed, fontSize=28.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column { Text("BloodLine Member", fontWeight=FontWeight.Black); Text("Verification pending", color=Color.Gray) }
                    }
                }
            }
        }
        item { SecurityRow("🔐", "Secure account", "OTP + device/session controls") }
        item { SecurityRow("🛡", "Privacy", "Minimal location sharing + role-based access") }
        item { SecurityRow("📋", "Audit trail", "Requests and handovers should be traceable") }
        item { SecurityRow("🩸", "Donation history", "Keep a verified donation record") }
        item { SecurityRow("🌐", "Languages", "English • Hindi • Marathi") }
    }
}

@Composable fun SecurityRow(icon:String,title:String,sub:String) {
    Card(shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(icon,fontSize=22.sp); Spacer(Modifier.width(12.dp))
            Column { Text(title,fontWeight=FontWeight.Bold); Text(sub,color=Color.Gray,fontSize=12.sp) }
        }
    }
}

@Composable
fun AIAssistant() {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(horizontal=20.dp)) {
        Text("BloodLine AI", style=MaterialTheme.typography.headlineLarge)
        Text("Search and guidance assistant — not a replacement for a doctor or blood-bank professional.", color=Color.Gray, fontSize=12.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value=query,onValueChange={query=it},label={Text("Ask: find O+ near me…")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick={},modifier=Modifier.fillMaxWidth()) { Text("Ask AI") }
        Spacer(Modifier.height(12.dp))
        if (query.isNotBlank()) {
            Card(shape=RoundedCornerShape(18.dp)) {
                Text("Demo response: I can help match your request, explain app steps, and surface verified centre data. Medical compatibility and transfusion decisions must be confirmed by qualified professionals.",Modifier.padding(16.dp))
            }
        }
    }
}
